package Evaluation;

public class Query {
	int queryNum ;
	String query ;
	
	public Query(int q , String s){
		this.queryNum = q ; 
		this.query = s ;
	}
	
}
